from typing import List, Optional

from pydantic_settings import BaseSettings, SettingsConfigDict

from core.filetypes import PROBE_ORDER


class Settings(BaseSettings):
    """Единая точка конфигурации сервиса. Значения берутся из .env / окружения."""

    # ------------------------------------------------------------------ Общие
    TZ: str = "UTC"
    COMPOSE_PROFILES: str = "api"
    LOG_LEVEL: str = "INFO"

    # ------------------------------------------------------------ База данных
    POSTGRES_USER: str = "knowledge_user"
    POSTGRES_PASSWORD: str = "secure_password"
    POSTGRES_DB: str = "knowledge"
    POSTGRES_PORT: int = 5432
    DATABASE_URL: str = "postgresql://knowledge_user:secure_password@postgres:5432/knowledge"

    # --------------------------------------------------------- Redis / Celery
    REDIS_PORT: int = 6379
    CELERY_BROKER_URL: str = "redis://redis:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://redis:6379/0"
    EVENT_BROKER_URL: str = "redis://redis:6379/1"
    EVENT_STREAM_NAME: str = "document_events"

    # ------------------------------------------------------------- Хранилище
    STORAGE_TYPE: str = "local"                 # local | s3
    STORAGE_LOCAL_MOUNT: str = "/data/shared"
    S3_ENDPOINT: Optional[str] = None
    S3_ACCESS_KEY: Optional[str] = None
    S3_SECRET_KEY: Optional[str] = None
    S3_BUCKET: Optional[str] = None
    RAW_PARSE_S3_PREFIX: str = "raw_parse/"

    # Где Parser ищет входные файлы по s3_fileid (контракт RAG <-> Parser).
    SOURCE_PREFIX: str = "documents/"
    # Расширения, которые перебираются, если s3_fileid пришёл без расширения.
    # Значение по умолчанию собирается из core.filetypes — единого реестра
    # поддерживаемых форматов, чтобы список не расходился с ним.
    SOURCE_PROBE_EXTENSIONS: List[str] = ["." + ext for ext in PROBE_ORDER]
    # Куда складываются изображения, вырезанные из PDF.
    ASSETS_PREFIX: str = "assets/"

    # ------------------------------------------- Парсер документов (MinerU2.5-Pro)
    # Единая модель на все форматы: текст, таблицы, формулы и картинки
    # разбирает она же. Запуск локальный, через Transformers — только этот
    # бэкенд укладывается в 8 ГБ VRAM.
    VLM_PORT: int = 8000
    VLM_ENDPOINT: str = "http://vlm:8000"
    VLM_TIMEOUT: int = 900
    VLM_PRIMARY_MODEL: str = "/models/mineru-2605-pro"
    # Вторая модель каскада. У 2605-Pro известен регресс на векторных
    # чертежах (пустой результат там, где 2509 отрабатывает), а чертежи для
    # этой установки главные — поэтому пустая страница переразбирается.
    VLM_FALLBACK_MODEL: str = "/models/mineru-2509"
    VLM_FALLBACK_ENABLED: bool = True
    # Держать обе модели в VRAM резидентно. По умолчанию нет: одна модель в
    # памяти за раз — это гарантия бюджета, вторая грузится по требованию.
    VLM_KEEP_BOTH: bool = False
    VLM_RENDER_DPI: int = 200
    VLM_MAX_SIDE: int = 1800
    VLM_ENABLE_IMAGE_PARSING: bool = True
    # Признаки «страница разобрана пусто», по которым включается вторая модель.
    VLM_EMPTY_RATIO: float = 0.4
    VLM_MIN_CHARS: int = 8
    VLM_MODEL_CACHE: str = "/models"

    # --------------------------------------------------------------- Florence
    FLORENCE_PORT: int = 8001
    FLORENCE_ENDPOINT: str = "http://florence:8000"
    FLORENCE_TIMEOUT: int = 120
    BATCH_SIZE: int = 32
    FLORENCE_MODEL_CACHE: str = "/models/florence-2-ft"

    # ------------------------------------------------------------------- YOLO
    DETECTOR_PORT: int = 8002
    DETECTOR_ENDPOINT: str = "http://detector:8000"
    DETECTOR_TIMEOUT: int = 60
    DETECTOR_CATEGORIES: List[str] = [
        "size", "tolerance", "roughness", "title_block",
        "material", "note", "radius", "thread", "callout",
    ]
    # Если детектор ничего не нашёл (например, стоковые веса YOLO не знают
    # категорий чертежа) — сначала распознаём надписи листа построчно и
    # разбираем их правилами чертежа: поля получают свои места и категории.
    DRAWING_OCR_LINES_FALLBACK: bool = True
    # Последнее средство: лист уходит в модель целиком и возвращается одним
    # полем с полнотой 0.
    DRAWING_FULL_OCR_FALLBACK: bool = True
    YOLO_MODEL_CACHE: str = "/models/yolo"

    # -------------------------------------------------- Приём документов
    # Профиль отсева: какие данные эта установка считает знанием.
    GATEWAY_PROFILE_PATH: str = "config/profile.yaml"
    # Классификатор приёма (слои G-2, G-3, G-4). Пусто — решают правила.
    CLASSIFIER_ENDPOINT: Optional[str] = None
    CLASSIFIER_TIMEOUT: int = 30
    GATEWAY_PORT: int = 8010
    QUALITY_GATE_PORT: int = 8011
    # Адреса соседей в цепочке приёма: gateway -> quality gate -> нормализатор.
    QUALITY_GATE_ENDPOINT: str = "http://quality_gate:8000"
    PARSER_ENDPOINT: str = "http://ingest_api:8000"
    INTAKE_TIMEOUT: int = 120

    # ------------------------------------------------- Проверка качества
    # Семантическое сходство выше порога — флаг «обновление или дубль».
    QG_SIMILARITY_THRESHOLD: float = 0.85
    # Документ старше этого срока сопровождается предупреждением.
    QG_MAX_AGE_DAYS: int = 1825
    # Уверенность быстрого OCR: ниже первого порога — предупреждение,
    # ниже второго — блокировка.
    QG_OCR_WARN_CONFIDENCE: float = 0.65
    QG_OCR_BLOCK_CONFIDENCE: float = 0.35
    # Сколько первых страниц осматривает быстрый OCR.
    QG_OCR_PAGES: int = 2

    # ------------------------------------------------- Лестница стратегий
    # Оценка, начиная с которой результат уровня считается достаточным и
    # подъём прекращается. Ниже — маршрутизатор пробует следующий уровень.
    LADDER_SCORE_THRESHOLD: float = 0.75
    # Какие уровни включены в этой установке. Профиль может отключить
    # дорогие уровни, не трогая код: 1 исходник САПР, 2 текстовый слой,
    # 3 табличный разбор, 4 распознавание без структуры, 5 детекция
    # областей, 6 восстановление растра плюс 5, 7 мультимодальная модель.
    LADDER_ENABLED_LEVELS: List[int] = [1, 2, 3, 4, 5, 6, 7]

    # ------------------------------------------- Эскалация модели (уровень 7)
    # Тот же сервис, но дороже: страница рендерится крупнее и сразу второй
    # моделью каскада. Применяется, когда уровни 5 и 6 оставили
    # неоднозначность — на мелком сером тексте и плохих сканах это решает.
    VLM_ESCALATION_ENABLED: bool = True
    VLM_ESCALATION_DPI: int = 300
    VLM_ESCALATION_MAX_SIDE: int = 2400

    # ---------------------------------------------------------- Бизнес-логика
    DEFAULT_CHUNK_SIZE: int = 500
    DEFAULT_OVERLAP: int = 50
    MIN_CHUNK_SIZE: int = 30
    COMPLETENESS_THRESHOLD: float = 0.5
    CONFIDENCE_THRESHOLD: float = 0.6
    PROCESSING_TIMEOUT_SECONDS: int = 900
    DEFAULT_LANGUAGE: str = "ru"

    # ----------------------------------------------------------------- Celery
    CELERY_TASK_TIME_LIMIT: int = 600
    CELERY_TASK_SOFT_TIME_LIMIT: int = 540
    CELERY_ML_QUEUE: str = "ml_gpu"
    CELERY_TASK_MAX_RETRIES: int = 3

    # ------------------------------------------------------ Результат запроса
    # Сколько держать готовый результат для GET /internal/v1/parse/results/{id}
    RESULT_TTL_SECONDS: int = 86400
    # Опциональный push-канал поверх поллинга: none | redis_streams | callback | nats
    RESULT_DELIVERY_TYPE: str = "none"
    RESULT_CALLBACK_URL: Optional[str] = None
    RESULT_STREAM_NAME: str = "normalization_results"
    RESULT_CONSUMER_GROUP: str = "normalizer_group"
    NATS_SERVERS: Optional[str] = None
    NATS_STREAM_NAME: str = "normalization_results"
    NATS_SUBJECT: str = "normalization.result"

    # ------------------------------------------------------------------ Прочее
    HF_TOKEN: Optional[str] = None
    API_PORT: int = 8000

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )


settings = Settings()
